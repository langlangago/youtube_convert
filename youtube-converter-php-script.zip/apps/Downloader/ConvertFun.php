<?php

function grabUrl($url)
	{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$uaa = $_SERVER['HTTP_USER_AGENT'];
	curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: $uaa");
	return curl_exec($ch);
	}

function samgrab($url)
	{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, '2');
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	$header[] = "Accept-Language: en";
	$header[] = "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 6.0; de; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3
";
	$header[] = "Pragma: no-cache";
	$header[] = "Cache-Control: no-cache";
	$header[] = "Accept-Encoding: gzip,deflate";
	$header[] = "Content-Encoding: gzip";
	$header[] = "Content-Encoding: deflate";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	$load = curl_exec($ch);
	curl_close($ch);
	return $load;
	}

function sam($content, $start, $end)
	{
	if ($content && $start && $end)
		{
		$r = explode($start, $content);
		if (isset($r[1]))
			{
			$r = explode($end, $r[1]);
			return $r[0];
			}

		return '';
		}
	}
	
function count_format($n, $point='.', $sep=',') {
    if ($n < 0) {
        return 0;
    }

    if ($n < 10000) {
        return number_format($n, 0, $point, $sep);
    }

    $d = $n < 1000000 ? 1000 : 1000000;

    $f = round($n / $d, 1);

    return number_format($f, $f - intval($f) ? 1 : 0, $point, $sep) . ($d == 1000 ? 'k' : 'M');
}

function limit_words($string, $word_limit)
	{
	$words = explode(" ", $string);
	return implode(" ", array_splice($words, 0, $word_limit));
	}
	
function dateyt($date)
{
$date = substr($date,0,10); 
$date = explode('-',$date);
$mn   = date('F',mktime(0,0,0,$date[1])); 
$dates= ''.$date[2].' '.$mn.' '.$date[0].''; 
return $dates;
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }
    

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function get_data($url) {
	$ch = curl_init();
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}

function format_time($t) 
{

$tcheck = str_replace('PT','',$t);
$tcheck = str_replace('H',' H ',$tcheck);
$tcheck = str_replace('M',' M ',$tcheck);
$tcheck = str_replace('S',' S ',$tcheck);

//convert to array
$arr = explode(' ', $tcheck);

$hasil = str_replace('PT','',$t);

$hasil = str_replace('H',':',$hasil);

if (!in_array('S', $arr) ):

$hasil = str_replace('M',':00',$hasil);

else:

$hasil = str_replace('M',':',$hasil);

endif;

$hasil = str_replace('S','',$hasil);

return $hasil;
}

function vedio_info($id,$key){

$yf = grabUrl('https://www.googleapis.com/youtube/v3/videos?key=' . $key . '&part=snippet,contentDetails,statistics,topicDetails&id=' . $id . '&vid=' . $id . '');

$yf = json_decode($yf);

if (!$yf):
    
exit('Error: Somthing is wrong! Please Try again.');

endif;
	    
	foreach($yf->items as $item)
		{
		$name = $item->snippet->title;
		$title = $name;
		$image = 'https://i.ytimg.com/vi'.DS.$id.DS.'mqdefault.jpg';
		$date = dateyt($item->snippet->publishedAt);
		$published = time_elapsed_string($item->snippet->publishedAt);
		$ctd = $item->contentDetails;
		$st = $item->statistics;
		$duration = format_time($ctd->duration);
		$views = $st->viewCount;
		
		}

	
  return (object) ['title'=>$title,'image'=>$image,'date'=>$date,'published'=>$published,'duration'=>$duration,'views'=>$views];

	

}