<?php

 class smartyModel {
  
 public function users($id){
 
 global $smarty;
 
 switch ($id):
    
 case '0':

 case NULL:

 define('IsLogged',false);

 $smarty->assign('notlogged', true);
  
 $smarty->assign('logged',false);
 
 break;

 default:
 
 define('IsLogged',true);

 $smarty->assign('logged', true);

 $smarty->assign('notlogged',false);
 
 break;

 endswitch;

  }
 
 public function sign_option(){
     
 global $smarty,$query,$info,$option,$uid,$HOST;

 $option = $query->opt_all('value,header','options');

 $smarty->assign('HOST',$HOST); 
 
 $smarty->assign('site_url',$_SERVER['HTTP_HOST']); 

 $smarty->assign('THEME',Theme);
 
 $smarty->assign('date',Year);
 
 $smarty->assign('name',$option['0']['0']);
 
 $smarty->assign('reCAPTCHA_site_key',$option['1']['0']);
 
 $smarty->assign('reCAPTCHA_secret_key',$option['2']['0']);

 $smarty->assign('Favicon_url',$option['14']['0']);

 $smarty->assign('site_description',$option['4']['0']);

 $smarty->assign('site_title',$option['5']['0']);

 $smarty->assign('keywords',$option['24']['0']);

 $smarty->assign('language',$option['6']['0']);

 $smarty->assign('support_email',$option['7']['0']);

 $smarty->assign('code_head',$option['8']['0']);

 $smarty->assign('banner_home_728x90',$option['25']['0']);

 $smarty->assign('ads_home',$option['26']['0']);

 $smarty->assign('banner_video_468x601',$option['27']['0']);

 $smarty->assign('ads_video',$option['28']['0']);

 $smarty->assign('banner_sidebare',$option['29']['0']);

 $smarty->assign('order_by',$option['15']['0']);

 $smarty->assign('APPversion',$info->version);

 $smarty->assign('youtube_api',$option['16']['0']);

 $smarty->assign('body_code',$option['17']['0']);
 
 $smarty->assign('num_vedios',$option['19']['0']);

 $smarty->assign('home_color',$option['20']['0']);

 $smarty->assign('captcha_url_check',$option['22']['0']);

 $smarty->assign('captcha_admin_login',$option['23']['0']);
 
 if (isset($uid)):

 $user = $query->addquery('select','members','*','i', $uid,'user_id=?');
 
 $smarty->assign('role',$user->role);

 endif;
 
 }
 
 public function sign_user_fun(){
 
 global $smarty,$query,$option,$uid,$HOST;

 if(isset($uid)):
     
 $user = $query->addquery('select','members','*','i', $uid,'user_id=?');
 
 endif;
 
 //username
 $smarty->assign('username',$user->username);
 
 }
 
 }


$smart = new smartyModel;
