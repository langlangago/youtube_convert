<?php

 //website url
 
 class get_host{
    
 public function site_protocol(){
    
 $protocol = isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] === 1) || isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ? 'https' : 'http';

 return $protocol;

 }

 public function site_url(){

 return $this->site_protocol() . '://' . $_SERVER['HTTP_HOST'] . DS ;

 }

 }

 $hs = new get_host;

 //check for curl extension
 
 function _is_curl_installed() {
    if  (in_array  ('curl', get_loaded_extensions())) {
        return true;
    }
    else {
        return false;
    }
 }

 //Redirect - header option 
 
 function Redirect($result,$refresh = false, $permanent = false) {
    
    global $hs,$HOST;
    
	if($permanent) {
	
	header('HTTP/1.1 301 Moved Permanently');
	
	}
	
	if ($refresh){
	
	 if (empty($result['controller']) && isset($result['action'])){
	    
	 header('refresh:3;url= '.$HOST.$result['action']);

	  }

	 elseif (isset($result['action'])){
	    
	 header('refresh:3;url= '.$HOST.$result['controller'].DS.$result['action']);

  	 }
	  }
   
	else{
	    
	 if (empty($result['controller']) && isset($result['action'])){

	 header('Location: '.$HOST.$result['action']);

	 }
	
  	 elseif (isset($result['action'])){

	 header('Location: '.$HOST.$result['controller'].DS.$result['action']);

	 }
	}

    exit();
}

 //delete files - dir
 
 function delete_files($target) {
    if(is_dir($target)){
        $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned
        
        foreach( $files as $file )
        {
            delete_files( $file );      
        }

        rmdir( $target );
    } elseif(is_file($target)) {
        unlink( $target );  
    }
 }


 //recaptcha
 
 function ReCaptcha($reCAPTCHA_secret_key=false){

 $info = [
 'secret' => $reCAPTCHA_secret_key,
 'response' => $_POST['g-recaptcha-response']];

 $verify = curl_init();
 
 curl_setopt($verify, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
 curl_setopt($verify, CURLOPT_POST, true);
 curl_setopt($verify, CURLOPT_POSTFIELDS, http_build_query($info));
 curl_setopt($verify, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($verify, CURLOPT_RETURNTRANSFER, true);
 $response = curl_exec($verify);

 $data = json_decode($response);

 if( isset($data->success) && $data->success == true){

  return true;
 }elseif($data->error-codes || $data->challenge_ts || $data->hostname || $data->success == false){

  return false;

 }
 
 }

 //check for inputs requests
 
 function check_request($result,$func=false,$mode=false){

 if(!empty($result)){
    
  if(!$mode):

   if ($func):
      
    $result = filter_var($func($_POST[$result]), FILTER_SANITIZE_STRING);

   else:

    $result = filter_var($_POST[$result], FILTER_SANITIZE_STRING);
    
   endif;
   
       return $result;
       
    if(empty($result) || !filter_var($result, FILTER_SANITIZE_STRING)):
     
       return false;

     endif;

   elseif($mode):

   switch($mode):
     
   case 'email':

   if ($func):
      
    $result = filter_var($func($_POST[$result]), FILTER_VALIDATE_EMAIL);

   else:

    $result = filter_var($_POST[$result], FILTER_VALIDATE_EMAIL);
    
   endif;

       return $result;

    if(empty($result) || !filter_var($result, FILTER_VALIDATE_EMAIL)):
     
       return false;
       
     endif;
     
  break;
  
  case 'int':
      
   if ($func):
      
    $result = filter_var($func($_POST[$result]), FILTER_VALIDATE_INT);

   else:

    $result = filter_var($_POST[$result], FILTER_VALIDATE_INT);
    
   endif;

       return $result;

    if(empty($result) || !filter_var($result, FILTER_VALIDATE_INT)):
     
       return false;
       
     endif;
 
  break;
  
  case 'ip':
      
   if ($func):
      
    $result = filter_var($func($_POST[$result]), FILTER_VALIDATE_IP);

   else:

    $result = filter_var($_POST[$result], FILTER_VALIDATE_IP);
    
   endif;

       return $result;

    if(empty($result) || !filter_var($result, FILTER_VALIDATE_IP)):
     
       return false;
       
     endif;
 
  break;
  
  case 'url':
      
   if ($func):
      
    $result = filter_var($func($_POST[$result]), FILTER_VALIDATE_URL);

   else:

    $result = filter_var($_POST[$result], FILTER_VALIDATE_URL);
    
   endif;

       return $result;

    if(empty($result) || !filter_var($result, FILTER_VALIDATE_URL)):
     
       return false;
       
     endif;
 
  break;
 
  endswitch;
     
  endif;
  
 }
 }


 //server request
 
 class Request{

	public function csrf_token() {

		if(isset($_SESSION['csrfToken'])) 

			return $_SESSION['csrfToken']; 

		else{

			$token = bin2hex(openssl_random_pseudo_bytes(32));

			$_SESSION['csrfToken'] = $token;

			return $token;

		}

	}
	
    public function post(){

if($_SERVER["REQUEST_METHOD"]== 'POST' && $this->csrf_token()== $_POST['csrf']){

if(count(array_filter($_POST))!=count($_POST)){

  return 'empty';
}

else{

  return 'true';
}

  }
else{

    return 'false';
}
  
   }
   
   
    public function get(){

if($_SERVER["REQUEST_METHOD"]== 'GET' && $this->csrf_token()== $_GET['id']){

if(count(array_filter($_GET))!=count($_GET)){

  return 'empty';
}

else{

  return 'true';
}

  }
else{

    return 'false';
}
  
   }
}

 $sr = new Request;

//assign csrf token

$smarty->assign('csrfToken',$sr->csrf_token());


 //display - smarty 
 
  function Show($path = ''){
  
  global $smarty;
 
 if(isset($path)){

 $smarty->display(WWW_ROOT . 'template/' . Theme . DS . $path . '.tpl');

 }
  }

 //ip
 
 $ip_visit = getenv('HTTP_CLIENT_IP')?:
    
 getenv('HTTP_X_FORWARDED_FOR')?:
    
 getenv('HTTP_X_FORWARDED')?:
    
 getenv('HTTP_FORWARDED_FOR')?:
    
 getenv('HTTP_FORWARDED')?:

 getenv('REMOTE_ADDR');

 //str function
 
 function startsWith($haystack, $needle) {
    // search backwards starting from haystack length characters from the end
    return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
 }

 function endsWith($haystack, $needle) {
    // search forward starting from end minus needle length characters
    return $needle === "" || (($temp = strlen($haystack) - strlen($needle)) >= 0 && strpos($haystack, $needle, $temp) !== false);
 }
 
 
 //write to files
 
 function WRITE($file,$content,$mode){
    
 $fp = fopen($file,$mode);

 fwrite($fp,$content);

 fclose($fp);

 }
 
 //check for errors write in => logs => reports.txt
 
 function errorAndDie($error_msg) {

 global $dateForm;

 $debug_file = ROOT.DS.'logs/reports.txt';

 if (!empty($debug_file)) {

 $report = 'Error: '.$dateForm.' | '.$error_msg.PHP_EOL; 

 WRITE($debug_file,$report,"a");

 die('Error: '.$error_msg);

  }
 }

 //activate session 
 
 function session_acv($name='',$action=''){

 if(isset($action)){

 $_SESSION[$name][$action]=true;

 }

 }
 

 //alerts
 
 function alerts($session,$alert){

 global $smarty;

 if(isset($_SESSION[$session][$alert])){
    
 $smarty->assign($alert,true);

 unset($_SESSION[$session]);
 
 }else{
     
 $smarty->assign($alert,false);
 }
	}
  

 //detect country
 
 function ip_visitor_country(){

 global $ip_visit;

 //optionally, you can specify the return type
 // type can be "code" (default), "abbr", "name"

 $countryCode = getCountryFromIP($ip_visit, "code");

 // full name of country - spaces are trimmed

 $countryName = getCountryFromIP($ip_visit, " NamE ");
    
    return (object) ["code" => $countryCode,"name" => $countryName];
 }

 //detect device
 
 function detectDevice($deviceName = false){
	$userAgent = $_SERVER["HTTP_USER_AGENT"];
	$devicesTypes = array(
        "PC" => array("msie 10", "msie 9", "msie 8", "windows.*firefox", "windows.*chrome", "x11.*chrome", "x11.*firefox", "macintosh.*chrome", "macintosh.*firefox", "opera"),
        "MOBILE" => array("mobile ", "android.*mobile", "iphone", "ipod", "opera mobi", "opera mini","tablet", "android", "ipad", "tablet.*firefox"),
        "BOT" => array("googlebot", "mediapartners-google", "adsbot-google", "duckduckbot", "msnbot", "bingbot", "ask", "facebook", "yahoo", "addthis")

    );
 	foreach($devicesTypes as $deviceType => $devices) {           
        foreach($devices as $device) {
            if(preg_match("/" . $device . "/i", $userAgent)) {
                $deviceName = $deviceType;
            }
        }
    }
    return ucfirst($deviceName);
 	}


 //check app version 
 
 function app_version(){

 $server = 'https://codsem.com/ytgrape/server/update?v=new';

 $ch = curl_init();

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

 curl_setopt($ch, CURLOPT_URL, $server);

 $result = curl_exec($ch);

 curl_close($ch);

 $arr = json_decode($result, true);

 return $arr;

 }