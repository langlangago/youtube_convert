<?php

 /*
 |--------------------------------------------------------------------------
 | Configuration & Connection & Functions & Models
 |--------------------------------------------------------------------------
 |
 | Load config file getting info.
 | load database connector file.
 | Load our functions file.
 | Load our smarty model files.
 |
 */

 if (!file_exists(dirname(__DIR__).'/config/app.php')):
     
 require_once (dirname(__DIR__).'/config/models/configModel.php');

 else:
     
 require_once ('config.php');
 
 endif;

 require_once (CONNECT.'dbconnect.class.php');

 require_once (MODELS.'smartyModel.php');

 require_once (CONFIG.'function.php');

 require_once (MODELS.'functionModel.php');

 if (DB_ERR && $info->install == 'on'):

 errorAndDie('Missing database parameter');

 endif;
 
 if (empty(HOST)):

 $HOST = $hs->site_url();

 else:
    
 $HOST = HOST;

 endif;

 //ON
 
 if ($info->install == 'on'):

 $uid = $se->new_session('user','logged','uid');

 $smart->users($uid);
 
 $smart->sign_option();
 
 if (isset($uid)):
     
 $user = $query->addquery('select','members','*','i', $uid,'user_id=?');
 
 endif;

 //OFF
 else:
 
  $fun->do_install();
  
 endif;