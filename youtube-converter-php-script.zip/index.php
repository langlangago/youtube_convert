<?php

//SEPARATE MAIN ROOT TO /WEBROOT
require 'webroot' . DIRECTORY_SEPARATOR . 'index.php';