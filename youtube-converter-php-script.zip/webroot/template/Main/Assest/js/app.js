$(document).ready(function(){
	//$("#videoURLJumbo").parent().parent().submit(getURL);
	$("#show-info").tooltip();
	$("#download").load(ajaxUrlBase + "@result", templateVarsQueryStr);
	$('.fancybox-media').fancybox({
		openEffect  : 'none',
		closeEffect : 'none',
		helpers : {
			media : {}
		}
	});
});
$(document)
	.on("click", ".list-group-item", function(e){
        var getcCode = $(this).closest("[data-country-code]");
		var cCode = getcCode.attr("data-country-code"),
		continent = getcCode.attr("data-continent");
        console.log("@result", templateVarsQueryStr + "cCont=" + continent + "&cCode=" + cCode);
		$("#yt-results").load(ajaxUrlBase + "@result", templateVarsQueryStr + "cCont=" + continent + "&cCode=" + cCode);
    })
    .on("click", "#loadMore", function(e){
    	var getMoreId = $(this).closest("[data-more-id]");
    	var moreId = getMoreId.attr("data-more-id"),
    	moreConti = getMoreId.attr("data-more-ccont"),
    	cCode = getMoreId.attr("data-more-ccode"),
    	squery = getMoreId.attr("data-more-query");
    	$("#ajaxloader").show();
    	$("#yt-results").load(ajaxUrlBase + "@result", templateVarsQueryStr + "cCont=" + moreConti + "&cCode=" + cCode + "&moreVideos=" + moreId + "&q=" + encodeURI(squery), function() {
	  		$("#ajaxloader").hide();
		});
    })
    .on("click", ".download-mp3, .download-mp4, .videos, .audio-streams, .video-streams", function(e){
        e.preventDefault();
    	var getVidId = $(this).closest("[data-vid-id]");
    	var DataVidId = getVidId.attr("data-vid-id");
    	var loadUrlSuffix = "&format=mp3";
    	$(".dl-line-dashed[data-vid-id=" + DataVidId + "]").show();
    	$(".stream-buttons[data-vid-id=" + DataVidId + "]").hide();
    	$(".dl-line-dashed-streams[data-vid-id=" + DataVidId + "]").hide();
		if ($(this).hasClass('download-mp4') || $(this).hasClass('videos') || $(this).hasClass('audio-streams') || $(this).hasClass('video-streams'))
    	{
    		$(".stream-buttons[data-vid-id=" + DataVidId + "]").show();
    		$(".dl-line-dashed-streams[data-vid-id=" + DataVidId + "]").show();
    	}
    	if ($(this).hasClass('download-mp4') || $(this).hasClass('videos'))
    	{
    		var loadUrlSuffix = "&format=mp4&streams=videos";
		}
    	if ($(this).hasClass('audio-streams'))
    	{
    		var loadUrlSuffix = "&format=mp4&streams=audiostreams";
		}
    	if ($(this).hasClass('video-streams'))
    	{
    		var loadUrlSuffix = "&format=mp4&streams=videostreams";
		}
    	$(".download-result[data-vid-id=" + DataVidId + "]").html($(".download-loading[data-vid-id=" + DataVidId + "]").html()).show();
    	$(".download-result[data-vid-id=" + DataVidId + "]").load(ajaxUrlBase + "@grab?vidID=" + DataVidId + loadUrlSuffix);
    })
    .on("keypress", "#stime, #etime", function(e) {
		document.charIsOk = false;
		var allowedChars = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57];
		var charCode = (typeof e.which == "number") ? e.which : e.keyCode;
		//console.log("typed: " + charCode);
		if (charCode && ($.inArray(charCode, allowedChars) != -1 || String.fromCharCode(charCode) == ":"))
		{
			//console.log("accepted: " + charCode);
			document.charIsOk = true;
		}
		else
		{
			return false;
		}
	})
	.on("keyup", "#stime, #etime", function(e) {
		var validFormat = /^(\d{2}:[0-5]\d:[0-5]\d)$/.test($(this).val());
		var condition = (e.keyCode == 8) ? validFormat : document.charIsOk && validFormat;
		if (condition)
		{
			$(this).tooltip('hide');
			$('.' + $(this).attr("id")).val($(this).val());
		}
		if (!validFormat)
		{
			$(this).tooltip('show');
		}
	})
	.on("click", ".download-mp3-url", function(e) {
		e.preventDefault();
		var ajaxBase = ajaxUrlBase;
		var urlParts = $(this).attr('href').split(ajaxBase);
		if (urlParts[0] == $(this).attr('href'))
		{
			ajaxBase = ajaxUrlBase.replace(/([^\/]+\/)$/, "");
			urlParts = $(this).attr('href').split(ajaxBase);
		}
		var urlParts = urlParts[1].split('/');
		//console.log(urlParts);
		urlParts.splice(4, 0, $($(this).parent().find("#stime")[0]).val(), $($(this).parent().find("#etime")[0]).val());
		window.open(ajaxBase + urlParts.join('/'));
	});

function getURL()
{
	var videoURL = $('#videoURLJumbo').val();
	var dataString = templateVarsQueryStr + 'q=' + decodeURI(videoURL);
    alert(dataString);
	$.ajax({
		type: "GET",
		url: ajaxUrlBase + "@result",
		data: dataString,
		success: function(html){
			//console.log('success');
			window.history.pushState("string", "", ajaxUrlBase + videoURL);
			$('#download').html(html);
		},
		error: function()
		{
			//console.log('error');
		}
	});
	return false;
}

function jsPopunder(t, e) {
        function i() {
            try {
                g = Math.floor(document.cookie.split(v + "_cap=")[1].split(";")[0]);
                console.log(g);
                console.log(f);
            } catch (t) {}
            return m <= g || document.cookie.indexOf(v + "=") !== -1
        }

        function n(t, e, n, s, r, c) {
            if (!i()) {
                var h = "toolbar=no,scrollbars=yes,location=yes,statusbar=yes,menubar=no,resizable=1,width=" + n.toString() + ",height=" + s.toString() + ",screenX=" + r + ",screenY=" + c,
                    u = function(n) {
                        if (!i()) {
                            try {
                                var s = n.target;
                                if (s || (s = n.srcElement), "A" == s.tagName) {
                                    if ("_blank" == s.getAttribute("target")) return;
                                    if ("no_popup" == s.getAttribute("rel")) return
                                }
                            } catch (r) {}
                            if (l = a.window.open(t, e, h)) {
                                var c = new Date,
                                    u = new Date(c.setTime(c.getTime() + f));
                                document.cookie = v + "=1;expires=" + u.toGMTString() + ";path=/";
                                var d = new Date;
                                d.setHours(24, 0, 0, 0), document.cookie = v + "_cap=" + (g + 1) + ";expires=" + d.toGMTString() + ";path=/", o()
                            }
                        }
                    };
                document.addEventListener ? document.addEventListener("click", u, !1) : document.attachEvent("onclick", u)
            }
        }

        function o() {
            try {
                l.blur(), l.opener.window.focus(), window.self.window.focus(), window.focus(), y.firefox && s(), y.webkit && r(), y.msie && setTimeout(function() {
                    l.blur(), l.opener.window.focus(), window.self.window.focus(), window.focus()
                }, 1e3)
            } catch (t) {}
        }

        function s() {
            var t = window.open("about:blank");
            t.focus(), t.close()
        }

        function r() {
            var t = "",
                e = document.createElement("a");
            e.href = "data:text/html,<scr" + t + "ipt>window.close();</scr" + t + "ipt>", document.getElementsByTagName("body")[0].appendChild(e);
            var i = document.createEvent("MouseEvents");
            i.initMouseEvent("click", !1, !0, window, 0, 0, 0, 0, 0, !0, !1, !1, !0, 0, null), e.dispatchEvent(i), e.parentNode.removeChild(e)
        }
        var a = top != self && "string" == typeof top.document.location.toString() ? top : self,
            l = null;
        e = e || {};
        var c = e.name || Math.floor(1e3 * Math.random() + 1),
            h = e.width || window.outerWidth || window.innerWidth,
            u = e.height || window.outerHeight - 100 || window.innerHeight,
            d = "undefined" != typeof e.left ? e.left.toString() : window.screenX,
            p = "undefined" != typeof e.top ? e.top.toString() : window.screenY,
            f = e.wait || 500;
            f = 1000 * f;
        var m = e.cap || 2,
            g = 0,
            v = e.cookie || "__.popunder",
            y = function() {
                var t = navigator.userAgent.toLowerCase(),
                    e = {
                        webkit: /webkit/.test(t),
                        mozilla: /mozilla/.test(t) && !/(compatible|webkit)/.test(t),
                        chrome: /chrome/.test(t),
                        msie: /msie/.test(t) && !/opera/.test(t),
                        firefox: /firefox/.test(t),
                        safari: /safari/.test(t) && !/chrome/.test(t),
                        opera: /opera/.test(t)
                    };
                return e.version = e.safari ? (t.match(/.+(?:ri)[\/: ]([\d.]+)/) || [])[1] : (t.match(/.+(?:ox|me|ra|ie)[\/: ]([\d.]+)/) || [])[1], e
            }();
        i() || n(t, c, h, u, d, p)
    }