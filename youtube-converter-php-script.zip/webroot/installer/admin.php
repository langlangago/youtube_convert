<?php
//======================== STEP 3: CREATE ADMIN USER =========================//
//=============== IN STEP 3 WE GONE CREATE YOUR ADMIN PROFILE ================//
//================= THAT'S IT! YOUR INSTALATIONS COMPLETED ===================//
//============================== THANK YOU! ==================================//

require_once (dirname(__DIR__)."/loader.php");

require_once (DATA.'config.php');

if( isset($_POST['register'] ) ){

$username = $_POST['username'];

$password = md5($_POST['password']);

$email = $_POST['email'];

$passwordcheck = md5($_POST['passwordcheck']);

$website=$_POST['website'];

if($password == $passwordcheck){

  $query->addquery('insert','members','username,status,password,email,role,created','sissss',[$username,'1',$password,$email,'admin',$dateForm]);

  if(!endsWith($website, '/')):
  
   $website = $website.DS;
  
  endif;

  $appConfig = get_app($website,Theme,'on','1.2.0',$sr->csrf_token(),'YT Grape',$dateForm,$dateForm);

  write(CONFIG.'app.php',$appConfig,'w');
  session_acv('success','express_login');
  header('location:'.$website.'auth/login');
  exit;

 }else{

 //pass error

 session_acv('errpass','passfaild');

  header('location: admin');
  exit;

}

}else{

alerts('errpass','passfaild');

}

show('Installer/admin');

?>