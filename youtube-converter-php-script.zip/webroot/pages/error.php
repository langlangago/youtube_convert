<?php
//================================== error ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');

//SHOW
show('Pages/Errors/index');

//================================== error =================================//

?>