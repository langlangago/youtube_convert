<?php
//================================== Terms ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');

$smarty->assign('termsp',base64_decode($option['11']['0']));

show('Pages/Terms/index');
//================================= Terms =================================//

?>