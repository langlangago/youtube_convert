<?php

//================================== Faqs ==================================//

//REQUIRED
require_once (dirname(dirname(__FILE__)).'/loader.php');

$smarty->assign('faqp',base64_decode($option['10']['0']));

show('Pages/Faq/index');

//================================== Faqs ==================================//

?>