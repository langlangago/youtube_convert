<?php

//=============================================================================>
//- ALL FUNCTIONS START FROM HERE
//=============================================================================>

 require_once "loader.php";

 //assign
 
 $smart->sign_user_fun();
 
 //expired
 
 if(empty($uid) || $uid == '0'){
    
 $_SESSION['success']['expired']=true;

 Redirect(['controller' => 'auth', 'action' => 'login']);

 }

 //not logged
 
 if( !isset($_SESSION['user']['logged'])) {

 Redirect(['controller' => 'auth', 'action' => 'login']);

 }

 //pages
 
 function pages($perpage = 15,$screen = 0){

 if (!isset($_GET['p']) || $_GET['p']==0 )
 $screen;
 else
 $screen=$_GET['p']-1;
 $start = $screen * $perpage;
 return array('perpage' => $perpage, 'screen' => $screen , 'start' => $start);
 }

 function paging($page,$last_page,$part,$custom=false){

 global $smarty;

 $paging = false;

 if($page != 1){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($page - 1).'">&lsaquo;</a></li>';
 }

 if($page > 4){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($page-$page+1).'">&laquo;</a></li>';
 }

 for($i=4;$i>0;$i--)
 
 if($page-$i>0){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($page-$i).'">'.($page-$i).'</a></li>';
 }

 if ($page == 0){
 $paging.='<li class="page-item"><a class="page-link">&rsaquo;</a></li>';
 }

 elseif($page == $last_page){
 $paging.='<li class="page-item"><a class="page-link">&lsaquo;</a></li>';
 }
 else{
 $paging.='<li class="active page-item"><a class="page-link">'.$page.'</a></li>';
 }

 for($i=1 ; $i<5 ; $i++)
 if($last_page-($page+$i)>0){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($page+$i).'">'.($page+$i).'</a></li>';
 }
 if ($page < $last_page - 5){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($last_page - 1).'">&raquo;</a></li>';
 }

 if ($page != $last_page-1){
 $paging.='<li class="page-item"><a class="page-link" href="'.$part.($page + 1).'">&rsaquo;</a></li>';
 }
 if($paging && !$custom){
     
     $smarty->assign('paging',$paging);

  }
  
 if($paging && $custom){
     
     return $paging;
     
  }
  
 }

 $with=array();

 $result = pages();

 $smarty->assign('protocol',$hs->site_protocol());

//================================= END FUNCTIONS ============================//
?>