<?php

 require_once ('loader.php');

 /*
==== WE ARE CHECKING IF YOUR VERSION HIGHER OR EQUAL TO 7.0.0.================//
== YOU CAN REMOVE THIS IF YOU ARE CONFIDENT THAT YOUR PHP VERSION IS SUFFICIENT.
*/
if (!version_compare(PHP_VERSION, '7.0.0', '>=')) {
    exit('Your PHP version must be equal or higher than 7.0.0 to use our script. Please ask your hosting company to update it.');
}

/*
=============== WE ARE CHECKING IF CURL EXTENTION IS ENABLED ================//
== YOU CAN REMOVE THIS IF YOU ARE CONFIDENT THAT YOUR PHP VERSION IS SUFFICIENT.
*/
if (!_is_curl_installed()) {
  exit ("cURL is NOT installed you need it to use our script, Please ask your hosting company to include it.");
    
}

/*
=============== WE ARE CHECKING IF OpenSSL EXTENTION IS ENABLED ==============//
== YOU CAN REMOVE THIS IF YOU ARE CONFIDENT THAT YOUR PHP VERSION IS SUFFICIENT.
*/
if (!extension_loaded('openssl')) {
 exit("OpenSSL is NOT installed, Please ask your hosting company to include it.");
}

//TOP Videos

$with= array();

$data = $query->limit('videos','*','Downloads','desc',$option['19']['0']);

while($res=$data->fetch_assoc()){
    
$ar=array('video_id'=>$res['video_id'],'title'=>$res['title'],'image'=>$res['image'],'views'=>$res['views'],'duration'=>$res['duration'],'vedio_date'=>$res['vedio_date'],'downloads'=>$res['Downloads'],'token'=>base64_encode($res['token']));

array_push($with,$ar);
}
$smarty->assign('with',$with);


//POST URL Video

if(isset($_POST['videoURL'])){

if ($sr->post() == 'true'){
    
//true

if (ReCaptcha($option['2']['0']) == true || $option['22']['0'] == '2'){

$b = str_replace(' ', '-', $_POST['videoURL']);
$b = str_replace('https://www.youtube.com/watch?v=', '', $b);
$b = str_replace('https://youtu.be/', '', $b);
$b = str_replace('youtube.com/embed/', '', $b);
$b = str_replace('youtube-nocookie.com/embed/', '', $b);
$b = str_replace('https://www.youtube.com/playlist?list=', '', $b);
$b = str_replace('http', '', $b);
$b = str_replace('www', '', $b);	
$b = preg_replace('/-+/', '-', $b);

//paramters

$country = ip_visitor_country();

$device = detectDevice();

//grabe info

$info = vedio_info($b,$option[16][0]);

//query select

$vedio = $query->addquery('select','videos','video_id,token,title','s',$b,'video_id=?');

$query->addquery('insert','downloads','v_id,title,country,ip,device,browser,platform,created','ssssssss',[$b,$info->title,$country->name,$ip_visit,$device,$fun->getBrowser()['name'],$fun->getBrowser()['platform'],$dateForm]);


if(!isset($vedio->video_id)):

//query insert

$data = $query->addquery('insert','videos','video_id,title,image,views,duration,vedio_date,country,ip,device,token,date,created,Downloads','sssssssssssss',[$b,$info->title,$info->image,$info->views,$info->duration,$info->date,$country->name,$ip_visit,$device,'',$current_month,$dateForm,'0']);

//token

$token = $data.bin2hex(openssl_random_pseudo_bytes(16));

//update

$query->addquery('update','videos','token=?','si',[$token,$data],'id=?');

$query->addquery('update','videos','Downloads=Downloads+?','ii',['1',$data],'id=?');

switch($option['15']['0']):

case 'title':

Redirect(['controller'=> 'video','action'=> 'index?v='.str_replace(' ','_',$info->title)]);

break;

case 'key':

Redirect(['controller'=> 'video','action'=> 'index?v='.base64_encode($token)]);

break;

endswitch;


else:

$query->addquery('update','videos','Downloads=Downloads+?','is',['1',$vedio->video_id],'video_id=?');

switch($option['15']['0']):

case 'title':

Redirect(['controller'=> 'video','action'=> 'index?v='.str_replace(' ','_',$vedio->title)]);

break;

case 'key':

Redirect(['controller'=> 'video','action'=> 'index?v='.base64_encode($vedio->token)]);

break;

endswitch;


endif;

}elseif(ReCaptcha($option['2']['0']) == false && $option['22']['0'] == '1'){

session_acv('URLError','wrong');

Redirect(['action' => 'home']);

}
}elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);

}elseif($sr->post() == 'empty'){

session_acv('URLError','required');

Redirect(['action' => 'home']);
}

}else{

alerts('URLError','wrong');

alerts('URLError','required');

}

show('Home/home');

?>