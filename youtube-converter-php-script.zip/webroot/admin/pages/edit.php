<?php

require_once ('../../functions.php');

if(!isset($_GET['p'])){

exit('PLEASE SELECT PAGE');

}else{

$data = $query->addquery('select','options','value','s',$_GET['p'],'header=?');

$smarty->assign('content',base64_decode($data->value));

if( isset($_POST['edit'] ) )
{

$request= check_request('editor1');

if ($request):

$content = base64_encode($_POST['editor1']);

$page = $_GET['p'];

$query->addquery('update','options','value=?','ss',[$content,$page],'header=?');

$_SESSION['success']['edit']=true;

header("location: edit?p=".$_GET['p']."");

endif;

}else
{

alerts('success','edit');

}
 
}

show('Admin/Pages/edit');

?>