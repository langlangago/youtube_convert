<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:08
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Pages/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9018763585bdebbe408ab32-44813131%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce44c7718e268202168c084f9a57a6a603041e01' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Pages/index.tpl',
      1 => 1526186188,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9018763585bdebbe408ab32-44813131',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbe40d6e51_63351009',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbe40d6e51_63351009')) {function content_5bdebbe40d6e51_63351009($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

 
    <title>Pages - Admin</title>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">Pages</h4>
                                    <p class="card-category">All Pages</p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class=" text-primary">
                                                
                                                <th>Pages</th>
                                                
                                                <th style="text-align: center">Published</th>
                                                
                                                <th style="text-align: center">Actions</th>
                                                

                                            </thead>
                                            <tbody>
                                                <tr>
                                                 <td><b>#Faqs</b></td>
                                                 
                                                 <td style="text-align: center">Yes</td>
                                                 
                                                 <td style="text-align: center">
                                 <form method="POST">
                        <div class="col-sm-8 col-sm-offset-3">
                        <div class="form-group">
                        <input type="hidden" name="p_id" value="faq"> 
                       <input class="btn btn-warning" type="submit" name="edit" value="Edit"/></div>
                               </div></form>
                                                 </td>

                                                </tr>
                                        <tr>
                                        <td><b>#Terms</b></td>

                        <td style="text-align: center">Yes</td>

                                 <td  style="text-align: center">
                                 <form method="POST">
                        <div class="col-sm-8 col-sm-offset-3">
                        <div class="form-group">
                        <input type="hidden" name="p_id" value="terms"> 
                       <input class="btn btn-warning btn-xs" type="submit" name="edit" value="Edit"/></div>
                               </div></form></td>

                    
                                        </tr>
                                        
                                        <tr>
                                        <td><b>#Policy</b></td>

                        <td style="text-align: center">Yes</td>

                                 <td  style="text-align: center">
                                 <form method="POST">
                        <div class="col-sm-8 col-sm-offset-3">
                        <div class="form-group">
                        <input type="hidden" name="p_id" value="policy"> 
                       <input class="btn btn-warning btn-xs" type="submit" name="edit" value="Edit"/></div>
                               </div></form></td>
                                        </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
