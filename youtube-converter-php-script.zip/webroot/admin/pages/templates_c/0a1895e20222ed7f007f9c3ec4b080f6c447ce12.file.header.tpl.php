<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:08
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7129500735bdebbe40db215-90419909%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0a1895e20222ed7f007f9c3ec4b080f6c447ce12' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/header.tpl',
      1 => 1526218754,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7129500735bdebbe40db215-90419909',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Favicon_url' => 0,
    'HOST' => 0,
    'THEME' => 0,
    'name' => 0,
    'username' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbe40eaf02_17859170',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbe40eaf02_17859170')) {function content_5bdebbe40eaf02_17859170($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['Favicon_url']->value;?>
">
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/css/material-dashboard.css?v=2.0.0">
    <!-- Documentation extras -->
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/assets-for-demo/demo.css" rel="stylesheet" />
    <!-- iframe removal -->
   </head>

<body class="">
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
" class="simple-text logo-normal">
                    <?php echo $_smarty_tpl->tpl_vars['name']->value;?>

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item active ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/dashboard">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/admins">
                            <i class="material-icons">account_box</i>
                            <p>Admin Users</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/videos">
                            <i class="material-icons">videocam</i>
                            <p>Vedios</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/downloads">
                            <i class="material-icons">cloud_download</i>
                            <p>Downloads</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/set/settings">
                     <i class="material-icons">settings</i>

                      <p>Settings</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/pages/index">
                           <i class="material-icons">library_add</i>
                            <p>Pages</p>
                        </a>
                    </li>
                    
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/log_history">
                           <i class="material-icons">loop</i>
                            <p>Login History</p>
                        </a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <a class="navbar-brand" href="#">Welcome <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
!</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form class="navbar-form">
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <button type="submit" class="btn btn-white btn-round btn-just-icon">
                                    <i class="material-icons">search</i>
                                    <div class="ripple-container"></div>
                                </button>
                            </div>
                        </form>
                        <ul class="navbar-nav">

                            <li class="nav-item dropdown">
                                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">person</i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
admin/set/settings">Settings</a>
                                    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
auth/logout">Logout</a>
                                    
                                </div>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar --><?php }} ?>
