<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:08
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8085167655bdebbe40ecd34-56860390%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c60abf6556f7e165a2e6664b1d0074d890b8d557' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/footer.tpl',
      1 => 1525505772,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8085167655bdebbe40ecd34-56860390',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'HOST' => 0,
    'APPversion' => 0,
    'date' => 0,
    'name' => 0,
    'THEME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbe40feab9_22663216',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbe40feab9_22663216')) {function content_5bdebbe40feab9_22663216($_smarty_tpl) {?>            <footer class="footer ">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
" target="_blank">
                                    Browse Website
                                </a>
                            </li>
                            <li>
                                <a href="https://codesem.com/" target="_blank">
                                    By Codesem
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <div class="copyright pull-right">
Version <?php echo $_smarty_tpl->tpl_vars['APPversion']->value;?>
 | <?php echo $_smarty_tpl->tpl_vars['date']->value;?>
 &copy; <a href="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</a>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/core/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/core/popper.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/bootstrap-material-design.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/plugins/perfect-scrollbar.jquery.min.js"><?php echo '</script'; ?>
>
<!--  Charts Plugin, full documentation here: https://gionkunz.github.io/chartist-js/ -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/plugins/chartist.min.js"><?php echo '</script'; ?>
>
<!-- Library for adding dinamically elements -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/plugins/arrive.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!--  Notifications Plugin, full documentation here: http://bootstrap-notify.remabledesigns.com/    -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/plugins/bootstrap-notify.js"><?php echo '</script'; ?>
>
<!-- Material Dashboard Core initialisations of plugins and Bootstrap Material Design Library -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/material-dashboard.js?v=2.0.0"><?php echo '</script'; ?>
>
<!-- demo init -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
template/<?php echo $_smarty_tpl->tpl_vars['THEME']->value;?>
/Assest/js/plugins/demo.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript">

    $(document).ready(function() {

        //init wizard

        // demo.initMaterialWizard();

        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.initCharts();

    });
<?php echo '</script'; ?>
>
<!-- -->

</html><?php }} ?>
