<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:10
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Log/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15965676585bdebbe6ae3f10-01400994%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cf94d1b95eb1e51e2d0299bbc20ccc07efa05fb3' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Log/index.tpl',
      1 => 1526215944,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15965676585bdebbe6ae3f10-01400994',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'with' => 0,
    'foo' => 0,
    'paging' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbe6b3e064_32919905',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbe6b3e064_32919905')) {function content_5bdebbe6b3e064_32919905($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

 
    <title>Login History - Admin</title>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title "> Login history</h4>
                                    <p class="card-category">All Login history</p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class=" text-primary">
                                                <th>
                                                    Ip Address
                                                </th>
                                                <th>
                                                    Status
                                                </th>
                                                <th>
                                                    Date
                                                </th>
                                            </thead>
                                            <tbody>
                           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>

                                                <tr>
                                                 <td>
                                            
                                            <?php echo $_smarty_tpl->tpl_vars['foo']->value['ip'];?>

                                        
                                                </td>

                                                    <td>
                                                         <?php if ($_smarty_tpl->tpl_vars['foo']->value['status']==1) {?>Success <?php } else { ?>Failed<?php }?>
                                                    </td>
                                                    <td>
                                                        <?php echo $_smarty_tpl->tpl_vars['foo']->value['date'];?>

                                                    </td>
                                                    
                                                </tr>
                                                   <?php } ?>
 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
<ul class="pagination pagination-primary"><?php echo $_smarty_tpl->tpl_vars['paging']->value;?>
</ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 

<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
