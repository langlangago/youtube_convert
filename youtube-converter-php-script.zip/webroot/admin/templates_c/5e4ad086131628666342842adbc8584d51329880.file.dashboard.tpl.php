<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:28:47
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/dashboard.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2672064145bdebbcf4a3396-92288563%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e4ad086131628666342842adbc8584d51329880' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Layout/dashboard.tpl',
      1 => 1526216252,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2672064145bdebbcf4a3396-92288563',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'app_version' => 0,
    'msg_version' => 0,
    'youtube_api' => 0,
    'countdown' => 0,
    'countvideos' => 0,
    'countadmins' => 0,
    'withL' => 0,
    'foo' => 0,
    'with' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbcf50a0b8_57323029',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbcf50a0b8_57323029')) {function content_5bdebbcf50a0b8_57323029($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <title>Dashboard - Admin </title>
            <div class="content">

                <div class="container-fluid">
<p><?php if ($_smarty_tpl->tpl_vars['app_version']->value) {
echo $_smarty_tpl->tpl_vars['msg_version']->value;
}?></p>

<p><?php if (empty($_smarty_tpl->tpl_vars['youtube_api']->value)) {?><div class="alert alert-danger">Error: Please set up your Youtube Api first!<?php }?></div></p>


                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-warning card-header-icon">
                                    <div class="card-icon">
                              <i class="material-icons">cloud_download</i>
                                      </div>
                                    <p class="card-category">Downloads</p>
                                    <h3 class="card-title"><?php echo $_smarty_tpl->tpl_vars['countdown']->value;?>

                                    </h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i> This Month
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-danger card-header-icon">
                                    <div class="card-icon">
                                <i class="material-icons">videocam</i>
                                         </div>
                                    <p class="card-category">Videos</p>
                                    <h3 class="card-title"><?php echo $_smarty_tpl->tpl_vars['countvideos']->value;?>
</h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>All time
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-success card-header-icon">
                                    <div class="card-icon">
                                        <i class="material-icons">account_box</i>
                                    </div>
                                    <p class="card-category">Admin Users</p>
                                    <h3 class="card-title"><?php echo $_smarty_tpl->tpl_vars['countadmins']->value;?>
</h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i> All time
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-info card-header-icon">
                                    <div class="card-icon">
                                        <i class="material-icons">library_add</i>
                                    </div>
                                    <p class="card-category">Pages</p>
                                    <h3 class="card-title">3</h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i> All time
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-md-12">
                            <div class="card">
                                <div class="card-header card-header-danger">
                                    <h4 class="card-title">Last Login</h4>
                                    <p class="card-category">Last 4 Login</p>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-hover">
                                        <thead class="text-danger">
                                            <th>ID</th>
                                            <th>Ip</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </thead>
                                        <tbody>
                                   <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['withL']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
                                            <tr>
                                                <td>#<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['ip'];?>
</td>
                                                <td><?php if ($_smarty_tpl->tpl_vars['foo']->value['status']==1) {?>Success<?php } else { ?>Failed<?php }?></td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['date'];?>
</td>
                                                 </tr>

                                                 <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6 col-md-12">
                            <div class="card">
                                <div class="card-header card-header-warning">
                                    <h4 class="card-title">Top Videos</h4>
                                    <p class="card-category">Top 4 Video (Most downloads)</p>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-hover">
                                        <thead class="text-warning">
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Downloads</th>
                                            <th>views</th>
                                        </thead>
                                        <tbody>
                                   <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>
                                            <tr>
                                                <td>#<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['title'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['downloads'];?>
</td>
                                                <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['views'];?>
</td>
                                                 </tr>

                                                 <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
