<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:28:56
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Users/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20415822195bdebbd8d777f7-45723303%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '178f67e27654a3e72e851150d24d3e673da7c2a1' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Users/index.tpl',
      1 => 1526215842,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20415822195bdebbd8d777f7-45723303',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'delete' => 0,
    'with' => 0,
    'foo' => 0,
    'paging' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbd8dd8931_58804207',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbd8dd8931_58804207')) {function content_5bdebbd8dd8931_58804207($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

 
    <title>Admin Users - Admin</title>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
<?php if ($_smarty_tpl->tpl_vars['delete']->value) {?><div class="alert alert-success">Video Deleted Successfully</div><?php }?>

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">Admins</h4>
                                    <p class="card-category">All Admin users</p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class=" text-primary">
                                                <th>User id</th>
                                                
                                                <th>Username</th>
                                                
                                                <th>Email</th>
                                                
                                                <th>Login ip</th>
                                                
                                                <th>Created</th>
                                                
                                                <th>Status</th>
                                                
                                                <th>Actions</th>

                                            </thead>
                                            <tbody>
                           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>

                                                <tr>
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['user_id'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['username'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['email'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['login_ip'];?>
</td>

                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['created'];?>
</td>
                                                 
                                                 <td><?php if ($_smarty_tpl->tpl_vars['foo']->value['status']==1) {?>Active<?php } else { ?>Inactive<?php }?></td>
                                                 
                                                 <td>
                                                 
                                               <form method="POST">
                                               
                                                <input type="hidden" name="u_id" value="<?php echo $_smarty_tpl->tpl_vars['foo']->value['user_id'];?>
">

                                                <input class="btn btn-danger" type="submit" name="delete" value="Delete">
                                               
                                               
                                               </form> 
                                               
                                                 </td>

                                                </tr>
                                                   <?php } ?>
 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
<ul class="pagination pagination-primary"><?php echo $_smarty_tpl->tpl_vars['paging']->value;?>
</ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 

<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
