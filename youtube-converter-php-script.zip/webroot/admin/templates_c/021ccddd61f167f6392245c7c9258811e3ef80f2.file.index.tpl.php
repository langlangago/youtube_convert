<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:01
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Downloads/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3740579235bdebbddb0a936-93096192%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '021ccddd61f167f6392245c7c9258811e3ef80f2' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Downloads/index.tpl',
      1 => 1526215696,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3740579235bdebbddb0a936-93096192',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'with' => 0,
    'foo' => 0,
    'paging' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbddb68047_40456345',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbddb68047_40456345')) {function content_5bdebbddb68047_40456345($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

 
    <title>Downloads - Admin</title>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">Downloads</h4>
                                    <p class="card-category">All downloads</p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class=" text-primary">
                                                <th>Id</th>
                                                
                                                <th>Title</th>
                                                
                                                <th>Youtube id</th>
                                                
                                                <th>Country</th>
                                                
                                                <th>Ip Address</th>
                                                
                                                <th>Device</th>
                                                
                                                <th>Browser</th>
                                                
                                                <th>Platform</th>

                                                <th>Created</th>

                                            </thead>
                                            <tbody>
                           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>

                                                <tr>
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['title'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['video_id'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['country'];?>
</td>

                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['ip'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['device'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['browser'];?>
</td>

                                                 <td> <?php echo $_smarty_tpl->tpl_vars['foo']->value['platform'];?>
</td>

                                                 <td> <?php echo $_smarty_tpl->tpl_vars['foo']->value['created'];?>
</td>

                                                </tr>
                                                   <?php } ?>
 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
<ul class="pagination pagination-primary"><?php echo $_smarty_tpl->tpl_vars['paging']->value;?>
</ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            
<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
