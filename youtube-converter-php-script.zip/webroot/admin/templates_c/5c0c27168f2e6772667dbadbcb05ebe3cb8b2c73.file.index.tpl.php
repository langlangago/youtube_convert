<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:28:59
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Videos/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:349800245bdebbdbc8fce0-97554627%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5c0c27168f2e6772667dbadbcb05ebe3cb8b2c73' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Videos/index.tpl',
      1 => 1526215766,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '349800245bdebbdbc8fce0-97554627',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'delete' => 0,
    'with' => 0,
    'foo' => 0,
    'paging' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbdbcf0273_05294829',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbdbcf0273_05294829')) {function content_5bdebbdbcf0273_05294829($_smarty_tpl) {?> <?php echo $_smarty_tpl->getSubTemplate ('../Layout/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <title>Videos - Admin</title>


             <div class="content">
                <div class="container-fluid">
                    <div class="row">
<?php if ($_smarty_tpl->tpl_vars['delete']->value) {?><div class="alert alert-success">Video Deleted Successfully</div><?php }?>

                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">List Videos</h4>
                                    <p class="card-category">All Posted Videos</p>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class=" text-primary">
                                                <th>Id</th>
                                                
                                                <th>Title</th>
                                                
                                                <th>Youtube id</th>
                                                
                                                <th>Views</th>
                                                
                                                <th>Duration</th>
                                                
                                                <th>Created</th>
                                                
                                                <th>Downloads</th>
                                                
                                                <th>Actions</th>

                                            </thead>
                                            <tbody>
                           <?php  $_smarty_tpl->tpl_vars['foo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['foo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['with']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->key => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
?>

                                                <tr>
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['title'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['video_id'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['views'];?>
</td>

                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['duration'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['vedio_date'];?>
</td>
                                                 
                                                 <td><?php echo $_smarty_tpl->tpl_vars['foo']->value['downloads'];?>
</td>

                                                 <td>
                                               <form method="POST">
                                               
                                                <input type="hidden" name="v_id" value="<?php echo $_smarty_tpl->tpl_vars['foo']->value['id'];?>
">

                                                <input class="btn btn-danger" type="submit" name="delete" value="Delete">
                                               
                                               
                                               </form>  </td>


                                                </tr>
                                                   <?php } ?>
 
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
<ul class="pagination pagination-primary"><?php echo $_smarty_tpl->tpl_vars['paging']->value;?>
</ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 


<?php echo $_smarty_tpl->getSubTemplate ('../Layout/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
