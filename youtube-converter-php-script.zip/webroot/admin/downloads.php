<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('downloads','*','id','desc',$result['screen'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'video_id'=>$res['v_id'],'country'=>$res['country'],'ip'=>$res['ip'],'device'=>$res['device'],'browser'=>$res['browser'],'platform'=>$res['platform'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);


paging($result['screen']+1,ceil($query->num_rows('downloads','*')/$result['perpage'])+1,'downloads?p=');

show('Admin/Downloads/index');

?>