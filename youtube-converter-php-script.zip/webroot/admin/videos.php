<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('videos','*','id','desc',$result['screen'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'video_id'=>$res['video_id'],'views'=>$res['views'],'duration'=>$res['duration'],'vedio_date'=>$res['vedio_date'],'downloads'=>$res['Downloads']);

array_push($with,$ar);
}
$smarty->assign('with',$with);


if( isset($_POST['delete'] ) ){

$request = check_request('v_id',false,'int');

if ($request):

$data = $query->addquery('delete','videos',false,'i',$request,'id=?');

$_SESSION['error']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'videos']);

endif;

}else{

alerts('error','delete');

}
paging($result['screen']+1,ceil($query->num_rows('videos','*')/$result['perpage'])+1,'videos?p=');

show('Admin/Videos/index');

?>