<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

//updates notices

if(app_version()['version'] > $info->version)
{

$_SESSION['error']['VersionNew']=true;

$alert_ver = '<div class="alert alert-danger">A new version '.app_version()['version'].' has been released click <a href="/admin/update?v='.app_version()['version'] .'">here</a> to update it!</div>';
}
else{
    
$smarty->assign('app_version',false);

}

//NEW VERSION
if(isset($_SESSION['error']['VersionNew'])) {

$smarty->assign('app_version',true);

$smarty->assign('msg_version',$alert_ver);

unset($_SESSION['error']);
}


// count downloads

$data = $query->addquery('select','videos','sum(Downloads) as countdown','s',$current_month,'date=?');

$smarty->assign('countdown',number_format($data->countdown));

// count admin users

$data = $query->addquery('select','members','count(user_id) as countadmins','s','admin','role=?');

$smarty->assign('countadmins',number_format($data->countadmins));

// count videos posted

$data = $query->addquery('select','videos','count(id) as countvideos');

$smarty->assign('countvideos',number_format($data->countvideos));

// Top 4 videos

$data = $query->limit('videos','*','Downloads','desc','4');
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'title'=>$res['title'],'views'=>$res['views'],'downloads'=>$res['Downloads']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

// Last 4 Logins

$withL = array();

$logins = $query->limit('log_history','*','id','asc','4');

while($res=$logins->fetch_assoc()){
    
$ar_L=array('id'=>$res['id'],'ip'=>$res['ip'],'status'=>$res['status'],'date'=>$res['date']);

array_push($withL,$ar_L);
}
$smarty->assign('withL',$withL);


show('Admin/Layout/dashboard');
?>