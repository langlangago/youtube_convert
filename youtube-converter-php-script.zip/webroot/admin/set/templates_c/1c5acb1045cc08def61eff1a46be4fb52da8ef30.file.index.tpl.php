<?php /* Smarty version Smarty-3.1.21-dev, created on 2018-11-04 09:29:04
         compiled from "/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Options/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4013895035bdebbe0353111-27315656%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c5acb1045cc08def61eff1a46be4fb52da8ef30' => 
    array (
      0 => '/home/codesem/public_html/ytgrape/webroot/template/Main/Admin/Options/index.tpl',
      1 => 1526185140,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4013895035bdebbe0353111-27315656',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'generale' => 0,
    'design' => 0,
    'interg' => 0,
    'captcha' => 0,
    'system' => 0,
    'name' => 0,
    'site_title' => 0,
    'site_description' => 0,
    'keywords' => 0,
    'HOST' => 0,
    'home_color' => 0,
    'Favicon_url' => 0,
    'code_head' => 0,
    'banner_home_728x90' => 0,
    'ads_home' => 0,
    'banner_video_468x601' => 0,
    'ads_video' => 0,
    'banner_sidebare' => 0,
    'captcha_type' => 0,
    'reCAPTCHA_site_key' => 0,
    'reCAPTCHA_secret_key' => 0,
    'captcha_admin_login' => 0,
    'captcha_url_check' => 0,
    'youtube_api' => 0,
    'order_by' => 0,
    'num_vedios' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5bdebbe03df768_58664511',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bdebbe03df768_58664511')) {function content_5bdebbe03df768_58664511($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("../Layout/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <title>Settings - Admin</title>

<div class="content">
  <div class="container-fluid">
   <div class="row">
    <div class="col-md-12">
        
<?php if ($_smarty_tpl->tpl_vars['generale']->value) {?>
<div class='alert alert-success' >You have changed <b>#Generale</b> website settings with success!</div>
 <?php }?>

  <?php if ($_smarty_tpl->tpl_vars['design']->value) {?>
<div class='alert alert-success' >You have changed your <b>#Design</b> website settings with success!</div>
<?php }?>
 
  <?php if ($_smarty_tpl->tpl_vars['interg']->value) {?>
<div class='alert alert-success' >You have changed your <b>#Integration</b> settings with success!</div>
<?php }?>

  <?php if ($_smarty_tpl->tpl_vars['captcha']->value) {?>
<div class='alert alert-success' >You have changed your <b>#Captcha</b> settings with success!</div>
<?php }?>


  <?php if ($_smarty_tpl->tpl_vars['system']->value) {?>
<div class='alert alert-success' >You have changed your <b>#System</b> settings with success!</div>
<?php }?>

    <div class="card card-nav-tabs card-plain">
        <div class="card-header card-header-primary">
             <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
        <div class="nav-tabs-navigation">
            <div class="nav-tabs-wrapper">
                <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                        <a class="nav-link <?php if ($_smarty_tpl->tpl_vars['generale']->value) {?>active<?php }?>" href="#General" data-toggle="tab">General</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php if ($_smarty_tpl->tpl_vars['design']->value) {?>active<?php }?>" href="#Design" data-toggle="tab">Design</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php if ($_smarty_tpl->tpl_vars['interg']->value) {?>active<?php }?>" href="#Integration" data-toggle="tab">Integration</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php if ($_smarty_tpl->tpl_vars['captcha']->value) {?>active<?php }?>" href="#Captcha" data-toggle="tab">Captcha</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php if ($_smarty_tpl->tpl_vars['system']->value) {?>active<?php }?>" href="#System" data-toggle="tab">System</a>
                    </li>
                </ul>
            </div>
        </div>
    </div><div class="card-body ">
        <div class="tab-content text-center">
            <div class="tab-pane <?php if (!$_smarty_tpl->tpl_vars['design']->value&&!$_smarty_tpl->tpl_vars['interg']->value&&!$_smarty_tpl->tpl_vars['captcha']->value&&!$_smarty_tpl->tpl_vars['system']->value) {?>active<?php }?>" id="General">
                    <form class="form form-horizontal" method="POST">
  
                <div class="form-group">
                            <label for="accountNumber" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                               Site Name
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-4" name="site_name" class="form-control" type="text" data-msg-required="The field must not be empty." maxlength="100"style="height: 45px;" value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
"/>
                                </div>
                            </div>
                      
                        
                        <div class="form-group">
                            <label for="accountNumber" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                               Site title
                            </label>
                            <div class="col-sm-6">
                                    <input  id="titleNum" name="site_title" class="form-control" type="text" style="height: 45px;" value="<?php echo $_smarty_tpl->tpl_vars['site_title']->value;?>
"/>
                                </div>
                         </div>

                        <div class="form-group">
                            <label for="accountNumber" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                                Description
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="descNum" name="site_desc" class="form-control" type="text" style="height:100px"><?php echo $_smarty_tpl->tpl_vars['site_description']->value;?>
</textarea>
                                </div>
                            </div>
                      
                        <div class="form-group">
                            <label for="accountNumber" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                                Keywords
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="descNum" name="keywords" class="form-control" type="text" style="height:100px"><?php echo $_smarty_tpl->tpl_vars['keywords']->value;?>
</textarea>
                                       <b>Note: Seperate keywords with a comma</b>
                                </div>
                            </div>
                            
                        <div class="form-group">
                            <label for="accountNumber" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Main Domain
                            </label>
                            <div class="col-sm-6">
                                    <input id="urlNum" name="main_domain" class="form-control" type="text" style="height: 45px;" value="<?php echo $_smarty_tpl->tpl_vars['HOST']->value;?>
"/>
                                       <b>Note: insert with <b>(http://)</b> Or <b>(https://)</b> and the trailing slash <b>(/)</b>. ex: http://domain.com/</b>
                                </div>
                            </div>


                        <div class= "form-group">  
                            <div class="col-sm-1 col-sm-offset-1">

                                <h5 style="color: red"></h5>
                                <h5 style="color: #00a000"></h5>

                                <br>
                                <input class="btn btn-info" name="Save_gen" type="submit" value="Save"/>
                                        
                            </div>
                        </div>

                    </form>

            </div>
            
            <div class="tab-pane <?php if ($_smarty_tpl->tpl_vars['design']->value) {?>active<?php }?>" id="Design">
                    <form class="form form-horizontal"  method="POST">
                     
                         <div class="form-group">
                            <label for="paymentWay" class="col-sm-1 control-label"style="white-space: nowrap; text-align: left; float: left;">

                               Home color
                            </label>
                            <div class="col-sm-6">
                                    <select id="form-control-6" name="home_color" class="form-control" style="height: 45px; ">
            <option value="" disabled="disabled">select</option>
            <option value="#4375d9"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['home_color']->value;?>
<?php $_tmp1=ob_get_clean();?><?php if ($_tmp1=='#4375d9') {?> selected="selected" <?php } else {
}?>>Blue</option>
   
            <option value="#f39c12"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['home_color']->value;?>
<?php $_tmp2=ob_get_clean();?><?php if ($_tmp2=='#f39c12') {?> selected="selected" <?php } else {
}?>>Yellow</option>
            <option value="#00a65a"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['home_color']->value;?>
<?php $_tmp3=ob_get_clean();?><?php if ($_tmp3=='#00a65a') {?> selected="selected" <?php } else {
}?>>Green</option>
   
            <option value="#dd4b39"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['home_color']->value;?>
<?php $_tmp4=ob_get_clean();?><?php if ($_tmp4=='#dd4b39') {?> selected="selected" <?php } else {
}?>>Red</option>
            <option value="#605ca8"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['home_color']->value;?>
<?php $_tmp5=ob_get_clean();?><?php if ($_tmp5=='#605ca8') {?> selected="selected" <?php } else {
}?>>Purple</option>
                                    </select>
                                </div>
                            </div>
                        <div class="form-group">
                            <label for="paymentWay" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                              Favicon URL
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-9" name="Favicon" class="form-control" type="text" style="height: 45px; " value="<?php echo $_smarty_tpl->tpl_vars['Favicon_url']->value;?>
"/>
                                </div>
                            </div>
                       
                        <div class= "form-group">  
                            <div class="col-sm-1 col-sm-offset-1">

                                <h5 style="color: red"></h5>
                                <h5 style="color: #00a000"></h5>

                                <br>
                                <input class="btn btn-info" name="Save_design" type="submit" value="Save" />
                                        
                            </div>
                        </div>

                    </form>            </div>
            
            <div class="tab-pane <?php if ($_smarty_tpl->tpl_vars['interg']->value) {?>active<?php }?>" id="Integration">
                    <form id="changeDataVO" class="form form-horizontal" data-toggle="validator" method="POST">
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                              Front Head Code
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="front_head" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['code_head']->value;?>
</textarea>
                                </div>
                      </div>
                       
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                              Banners home (728x90)
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="banner_home_728x90" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['banner_home_728x90']->value;?>
</textarea>
                                </div>
                      </div>
                      
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Ads home (Popups,Banners,iframes...)
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="ads_home" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['ads_home']->value;?>
</textarea>
                                </div>
                      </div>
                      
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;" >
                               Banners Video (468x60)
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="banner_video_468x601" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['banner_video_468x601']->value;?>
</textarea>
                                </div>
                      </div>
                      
                      
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Ads Video (Popups,Banners,iframes...)
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="ads_video" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['ads_video']->value;?>
</textarea>
                                </div>
                      </div>
                      
                 <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Banners Sidebare (325x50)
                            </label>
                            <div class="col-sm-6">
                                    <textarea id="form-control-9" name="banner_sidebare" class="form-control" type="text" style="height:100px" rows="4"><?php echo $_smarty_tpl->tpl_vars['banner_sidebare']->value;?>
</textarea>
                                </div>
                      </div>
                      
                        <div class= "form-group">  
                            <div class="col-sm-1 col-sm-offset-1">

                                <h5 style="color: red"></h5>
                                <h5 style="color: #00a000"></h5>

                                <br>
                                <input class="btn btn-info" name="Save_interg" type="submit" value="Save"/>
                                        
                            </div>
                        </div>

                    </form>
            </div>
            
            <div class="tab-pane <?php if ($_smarty_tpl->tpl_vars['captcha']->value) {?>active<?php }?>" id="Captcha">
                    <form id="changeDataVO" class="form form-horizontal" data-toggle="validator" method="POST">
                       <div class="form-group">
                            <label for="paymentWay" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                             Captcha Type
                            </label>
                            <div class="col-sm-6">
                                    <select id="form-control-6" name="captcha_type" class="form-control" style="height: 45px; ">
            <option value="recaptcha"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['captcha_type']->value;?>
<?php $_tmp6=ob_get_clean();?><?php if ($_tmp6=='recaptcha') {?> selected="selected" <?php } else {
}?>>Recaptcha</option>
                                    </select>
                                </div>
                            </div>
                      

                       <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                              reCAPTCHA Site key
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-4" name="recaptcha_key" class="form-control" type="text" style="height: 45px; " value="<?php echo $_smarty_tpl->tpl_vars['reCAPTCHA_site_key']->value;?>
"/>
                                </div>
                  </div>
                       <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                              reCAPTCHA Secret key
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-4" name="recaptcha_secret" class="form-control" type="text" style="height: 45px; " value="<?php echo $_smarty_tpl->tpl_vars['reCAPTCHA_secret_key']->value;?>
"/>
                                </div>
                            </div>
                  

                        <div class="form-group">
                            <label for="paymentWay" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Enable Captcha on Admin Login
                            </label>
                            <div class="col-sm-6">
                                    <select id="form-control-6" name="captcha_admin_login" class="form-control" style="height: 45px;">
                                        <option value="" disabled="disabled" selected="selected">Select...</option>
            <option value="1"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['captcha_admin_login']->value;?>
<?php $_tmp7=ob_get_clean();?><?php if ($_tmp7==1) {?> selected="selected" <?php } else {
}?>>Yes</option>
   
            <option value="2"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['captcha_admin_login']->value;?>
<?php $_tmp8=ob_get_clean();?><?php if ($_tmp8==2) {?> selected="selected" <?php } else {
}?>>No</option>

                                    </select>
                                </div>
                            </div>
                     
                        <div class="form-group">
                            <label for="paymentWay" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Enable Captcha on Url Checker
                            </label>
                            <div class="col-sm-6">
                                    <select id="form-control-6" name="captcha_url_check" class="form-control" style="height: 45px;">
                                        <option value="" disabled="disabled" selected="selected">Select...</option>
            <option value="1"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['captcha_url_check']->value;?>
<?php $_tmp9=ob_get_clean();?><?php if ($_tmp9==1) {?> selected="selected" <?php } else {
}?>>Yes</option>
   
            <option value="2"<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['captcha_url_check']->value;?>
<?php $_tmp10=ob_get_clean();?><?php if ($_tmp10==2) {?> selected="selected" <?php } else {
}?>>No</option>

                                    </select>
                                </div>
                    
                        </div>
                        
                        <div class= "form-group">  
                            <div class="col-sm-1 col-sm-offset-1">

                                <h5 style="color: red"></h5>
                                <h5 style="color: #00a000"></h5>

                                <br>
                                <input class="btn btn-info" name="Save_captcha" type="submit" value="Save"/>
                                        
                            </div>
                        </div>

                    </form>
            </div>
            
            <div class="tab-pane <?php if ($_smarty_tpl->tpl_vars['system']->value) {?>active<?php }?>" id="System">
                    <form id="changeDataVO" class="form form-horizontal" data-toggle="validator" method="POST">

                                   <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                              Youtube Api
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-4" name="youtube_api" class="form-control" type="text" style="height: 45px; " value="<?php echo $_smarty_tpl->tpl_vars['youtube_api']->value;?>
"/>
                                </div>
                            </div>
                            
                        <div class="form-group">
                            <label for="paymentWay" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;">
                               Url By
                            </label>
                            <div class="col-sm-6">
                                    <select id="form-control-6" name="orderBy" class="form-control" style="height: 45px;">
                                        <option value="" disabled="disabled" selected="selected">Select...</option>
            <option value="title"<?php if ($_smarty_tpl->tpl_vars['order_by']->value=='title') {?> selected="selected" <?php } else {
}?>>Title</option>
   
            <option value="key"<?php if ($_smarty_tpl->tpl_vars['order_by']->value=='key') {?> selected="selected" <?php } else {
}?>>Key</option>

                                    </select>
                                </div>
                    
                        </div>
                
                                   <div class="form-group">
                            <label for="accountNumber" class="col-sm-2 control-label"style="white-space: nowrap; text-align: left; float: left;"> 
                              Number vedios
                            </label>
                            <div class="col-sm-6">
                                    <input id="form-control-4" name="num_vedios" class="form-control" type="text" style="height: 45px; " value="<?php echo $_smarty_tpl->tpl_vars['num_vedios']->value;?>
"/>
                                </div>
                            </div>
                     
                        <div class= "form-group">  
                            <div class="col-sm-1 col-sm-offset-1">

                                <h5 style="color: red"></h5>
                                <h5 style="color: #00a000"></h5>

                                <br>
                                <input class="btn btn-info" name="Save_system" type="submit" value="Save"/>
                                        
                            </div>
                        </div>

                    </form>
            </div>
            
        </div>
    </div>
  </div>
  
        </div>
    </div>
  </div>
  
    </div>

<?php echo $_smarty_tpl->getSubTemplate ("../Layout/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
