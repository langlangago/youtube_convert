<?php

//============================= START SETTINGS ===============================//

require_once '../../functions.php';

if( isset($_POST['Save_gen'] ) ){

//POST==GENERAL 
$POST_name = $_POST['site_name'];
$POST_title = $_POST['site_title'];
$POST_desc = $_POST['site_desc'];
$POST_keywords = $_POST['keywords'];
$POST_domain = $_POST['main_domain'];

//UPDATE==TBL_CONFIG
$query->addquery('update','options','value=?','ss',[$POST_name,'name'],'header=?');
$query->addquery('update','options','value=?','ss',[$POST_title,'site_title'],'header=?');
$query->addquery('update','options','value=?','ss',[$POST_desc,'site_description'],'header=?');
$query->addquery('update','options','value=?','ss',[$POST_keywords,'keywords'],'header=?');

//update app file

$appConfig=get_app($POST_domain,Theme,$info->install,$info->version,$info->id,$info->app,$info->start,$info->update);

Write(CONFIG.'app.php',$appConfig,'w');

$_SESSION['success']['generale']=true;

header("location: settings");

}else{

alerts('success','generale');

alerts('error','err');

}


if( isset($_POST['Save_design'] ) ){

//POST==DESIGN 
$POST_Favicon = $_POST['Favicon'];
$POST_homeC = $_POST['home_color'];

//UPDATE==TBL_CONFIG
$query->addquery('update','options','value=?','ss',[$POST_homeC,'home_color'],'header=?');
$query->addquery('update','options','value=?','ss',[$POST_Favicon,'Favicon'],'header=?');

$_SESSION['success']['design']=true;

header("location: settings");

}else{

alerts('success','design');

alerts('error','err');

}

if( isset($_POST['Save_interg'] ) ){
    
$front_head = $_POST['front_head'];
$banner_home_728x90 = $_POST['banner_home_728x90'];
$ads_home = $_POST['ads_home'];
$banner_video_468x601 = $_POST['banner_video_468x601'];
$ads_video = $_POST['ads_video'];
$banner_sidebare = $_POST['banner_sidebare'];

$query->addquery('update','options','value=?','ss',[$front_head,'head_code'],'header=?');
$query->addquery('update','options','value=?','ss',[$banner_home_728x90,'banner_home_728x90'],'header=?');
$query->addquery('update','options','value=?','ss',[$ads_home,'ads_home'],'header=?');
$query->addquery('update','options','value=?','ss',[$banner_video_468x601,'banner_video_468x601'],'header=?');
$query->addquery('update','options','value=?','ss',[$ads_video,'ads_video'],'header=?');
$query->addquery('update','options','value=?','ss',[$banner_sidebare,'banner_sidebare'],'header=?');

$_SESSION['success']['interg']=true;
 
header("location: settings");
 
}else{

alerts('success','interg');

alerts('error','err');
	    
}

if( isset($_POST['Save_captcha'] ) ){
    
$enable_captcha = $_POST['enable_captcha'];
$captcha_type = $_POST['captcha_type'];
$recaptcha_key = $_POST['recaptcha_key'];
$recaptcha_secret = $_POST['recaptcha_secret'];
$captcha_Url = $_POST['captcha_url_check'];
$captcha_admin = $_POST['captcha_admin_login'];


$query->addquery('update','options','value=?','ss',[$enable_captcha,'enable_captcha'],'header=?');
$query->addquery('update','options','value=?','ss',[$captcha_type,'captcha_type'],'header=?');
$query->addquery('update','options','value=?','ss',[$recaptcha_key,'reCAPTCHA_site_key'],'header=?');
$query->addquery('update','options','value=?','ss',[$recaptcha_secret,'reCAPTCHA_secret_key'],'header=?');
$query->addquery('update','options','value=?','ss',[$captcha_Url,'captcha_url_check'],'header=?');
$query->addquery('update','options','value=?','ss',[$captcha_admin,'captcha_admin_login'],'header=?');

$_SESSION['success']['captcha']=true;
 
header("location: settings");
 
}else{
	    
alerts('success','captcha');

}



if( isset($_POST['Save_system'] ) ){
    
$youtube_api = $_POST['youtube_api'];

$orderBy = $_POST['orderBy'];

$num_vedios = $_POST['num_vedios'];

$query->addquery('update','options','value=?','ss',[$youtube_api,'youtube_api'],'header=?');

$query->addquery('update','options','value=?','ss',[$orderBy,'order_by'],'header=?');

$query->addquery('update','options','value=?','ss',[$num_vedios,'num_vedios'],'header=?');

$_SESSION['success']['system']=true;

header("location: settings");

}else{
	    
alerts('success','system');

}
	
	
show('Admin/Options/index');
//============================= END SETTINGS ===============================//
?>