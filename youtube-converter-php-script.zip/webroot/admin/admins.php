<?php

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('members','*','user_id','desc',$result['screen'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('user_id'=>$res['user_id'],'status'=>$res['status'],'username'=>$res['username'],'email'=>$res['email'],'login_ip'=>$res['login_ip'],'created'=>$res['created']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

if( isset($_POST['delete'] ) ){

$request = check_request('u_id',false,'int');

if ($request):

$data = $query->addquery('delete','members',false,'i',$request,'user_id=?');

$_SESSION['error']['delete']=true;

Redirect(['controller' => 'admin', 'action' => 'admins']);

endif;

}else{

alerts('error','delete');

}

paging($result['screen']+1,ceil($query->num_rows('members','*')/$result['perpage'])+1,'admins?p=');


show('Admin/Users/index');

?>