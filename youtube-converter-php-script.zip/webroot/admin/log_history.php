<?php

//================================= LOG_HISTORY ===============================>

require_once (dirname(dirname(__FILE__)).'/functions.php');

$data = $query->limit('log_history','*','id','desc',$result['screen'].','.$result['perpage']);
 
while($res=$data->fetch_assoc()){
    
$ar=array('id'=>$res['id'],'ip'=>$res['ip'],'status'=>$res['status'],'date'=>$res['date']);

array_push($with,$ar);
}
$smarty->assign('with',$with);

paging($result['screen']+1,ceil($query->num_rows('log_history','*')/$result['perpage'])+1,'log_history?p=');

show('Admin/Log/index');

?>