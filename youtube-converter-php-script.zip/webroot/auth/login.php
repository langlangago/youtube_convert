<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

//Logged

if(IsLogged):
    
Redirect(['controller' => 'admin', 'action' => 'dashboard']);

endif;

//=============================== START LOGIN ===============================//

if( isset($_POST['login'] ) ){

if ($sr->post() == 'true'){

if (ReCaptcha($option['2']['0']) == true || $option['23']['0'] == '2'){

$data=$query->addquery('select','members','user_id,password,status,role','s',check_request('username'),'username=?');

if($data->status == '2'){

session_acv('Usererror','banneduser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}

//CORRECT
if($data->password == check_request('password','md5') && $data->status == '1'){

$_SESSION['user']['logged'] = true;

$_SESSION['user']['uid'] = $data->user_id;

$query->addquery('update','members','login_ip=?','si',[$ip_visit,$data->user_id],'user_id=?');

$data = $query->addquery('insert','log_history','ip,status,date','sis',[$ip_visit,'1',$dateForm]);

Redirect(['controller' => 'admin', 'action' => 'dashboard']);

}else{

session_acv('Usererror','invaliduser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}

}elseif(ReCaptcha($option['2']['0']) == false && $option['23']['0'] == '1'){

session_acv('Usererror','wronguser');

Redirect(['controller' => 'auth', 'action' => 'login']);

}
 }

elseif($sr->post() == 'false'){

Redirect(['controller' => 'pages', 'action' => 'error']);
}

elseif($sr->post() == 'empty'){

session_acv('Usererror','requireduser');

Redirect(['controller' => 'auth', 'action' => 'login']);
}

}
else{
  //PENDING
alerts('Usererror','pendinguser');

    //BANNED
alerts('Usererror','banneduser');

    //INVALID
alerts('Usererror','invaliduser');

    //WRONG
alerts('Usererror','wronguser');

    //REQUIRED
alerts('Usererror','requireduser');


    //EXPIRED
alerts('success','expired');

    //ERROR
alerts('error','err');

    //GO_LOGIN
alerts('success','express_login');

}

show('Auth/Login/index');

//================================ END LOGIN =================================//
?>