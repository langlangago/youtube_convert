<?php

require_once (dirname(dirname(__FILE__)).'/loader.php');

session_destroy();

Redirect(['controller' => 'auth', 'action' => 'login']);

?>