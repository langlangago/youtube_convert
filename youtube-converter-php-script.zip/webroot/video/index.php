<?php

require_once dirname(__DIR__).'/loader.php';

if(!isset($_GET['v']) || empty($_GET['v'])):

Redirect(['action'=> 'home']);

endif;

//TOP Videos

$with= array();

$data = $query->limit('videos','*','Downloads','desc',$option['19']['0']);

while($res=$data->fetch_assoc()){
    
$ar=array('video_id'=>$res['video_id'],'title'=>$res['title'],'image'=>$res['image'],'views'=>$res['views'],'duration'=>$res['duration'],'vedio_date'=>$res['vedio_date'],'downloads'=>$res['Downloads'],'token'=>base64_encode($res['token']));

array_push($with,$ar);
}
$smarty->assign('with',$with);


switch($option['15']['0']):

case 'title':

$vid = base64_decode($_GET['v']);

$vedio = $query->addquery('select','videos','video_id,Downloads,title','s',$vid,'token=?');

if(isset($vedio->video_id)):

Redirect(['controller'=> 'video','action'=> 'index?v='.str_replace(' ','_',$vedio->title)]);

endif;

$vid = str_replace('_',' ',$_GET['v']);

$vedio = $query->normal("select video_id,Downloads from videos where title like '%$vid%'");

$vedio = (object) $vedio->fetch_assoc();

break;

case 'key':

$vid_title = str_replace('_',' ',$_GET['v']);

$vedio = $query->normal("select video_id,Downloads,token from videos where title like '%$vid_title%'");

$vedio = (object) $vedio->fetch_assoc();

if(isset($vedio->video_id)):

Redirect(['controller'=> 'video','action'=> 'index?v='.base64_encode($vedio->token)]);

endif;

$vid = base64_decode($_GET['v']);

$vedio = $query->addquery('select','videos','video_id,Downloads','s',$vid,'token=?');

break;

endswitch;

if(!$vedio || !$vedio->video_id):

Redirect(['action'=> 'home']);

endif;


$yf = grabUrl('https://www.googleapis.com/youtube/v3/videos?key=' . $option[16][0] . '&part=snippet,contentDetails,statistics,topicDetails&id=' . $vedio->video_id . '&vid=' . $vedio->video_id . '');

$yf = json_decode($yf);

 if (!$yf):
 
 exit('Somthing is wrong! Please try again.');
 
 endif;
	
	
	foreach($yf->items as $item)
		{
		
		$smarty->assign('VedID',$vedio->video_id);
        
		$smarty->assign('device',detectDevice());
        
		$smarty->assign('downloads',$vedio->Downloads);

		$smarty->assign('title',$item->snippet->title);

		$smarty->assign('image','https://i.ytimg.com/vi'.DS.$vedio->video_id.DS.'mqdefault.jpg');
		
		$smarty->assign('channelTitle',$item->snippet->channelTitle);
		
		$smarty->assign('channelId',$item->snippet->channelId);

		$smarty->assign('dateyt',dateyt($item->snippet->publishedAt));

		$ctd = $item->contentDetails;

		$st = $item->statistics;

		$smarty->assign('duration',format_time($ctd->duration));
		
		$smarty->assign('views',$st->viewCount);

		}


show('Vedios/index');

?>