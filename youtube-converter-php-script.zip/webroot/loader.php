<?php

/*
 * Load data file to hundle everythings see -> /config/ folder for more info.
*/
require_once (dirname(__DIR__).'/config/data.php');